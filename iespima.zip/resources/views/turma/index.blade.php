@extends(`layouts.app`)
@section(`conteudo`)
    {!! Form::open(array('url' => 'turma/lista')) !!}
    {!! Form::close() !!}
@endsection