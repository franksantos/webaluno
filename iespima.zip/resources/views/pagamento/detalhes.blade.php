<!-- aqui entrara a tela de detalhes do pagamento -->
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            {!! Form::label('Numero da Parcela') !!}
            {!! Form::text('num_parcela', $mensalidade->mes_num, ['disabled'=>'disabled','id'=>'num_parcela', 'class'=>'form-control']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('Data do Pagamento ( informada no comprovante )') !!}
            {!! Form::text('data_pagto', null, ['id'=>'data_pagto', 'class'=>'form-control', 'required'=>'required']) !!}

        </div>
        <div class="form-group">
            {!! Form::label('Hora do Pagamento ( informada no comprovante )') !!}
            {!! Form::text('hora_pagto', null, ['id'=>'hora_pagto', 'class'=>'form-control timepicker', 'required'=>'required']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('Lote do Pagamento ( informado no comprovante )') !!}
            {!! Form::text('lote_pagto', null, ['id'=>'lote_pagto', 'class'=>'form-control', 'required'=>'required']) !!}
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            {!! Form::label('Numero do Terminal usado no Pagamento ( informado no comprovante )') !!}
            {!! Form::text('terminal_pagto', null, ['id'=>'terminal_pagto', 'class'=>'form-control', 'required'=>'required']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('C&oacute;digo de Barras do Pagamento ( informado no comprovante )') !!}
            {!! Form::text('cod_barras_pagto', null, ['id'=>'cod_barras_pagto', 'class'=>'form-control', 'required'=>'required']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('Data de Vencimento da Parcela') !!}
            {!! Form::text('data_venc', $mensalidade->mes_data_venc->format('d/m/Y'), ['readonly'=>'readonly','id'=>'data_venc', 'class'=>'form-control']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('Valor Pago') !!}
            {!! Form::text('valor_parcela', $mensalidade->mes_valor, ['id'=>'valor_parcela','readonly'=>'readonly','class' => 'form-control']) !!}
        </div>
    </div>
</div>