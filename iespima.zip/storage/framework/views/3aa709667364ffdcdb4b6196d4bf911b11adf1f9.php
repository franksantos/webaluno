<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="box box-header">
            <h3 class="box-title">Cadastro de Turma</h3>
        </div>

        <!-- validacao de erros -->
        <?php if($errors->any()): ?>
            <ul class="alert alert-warning">
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <?php echo Form::open(array('url' => 'turma/store')); ?>

			<div class="form-group">
                <?php echo Form::label('Curso'); ?>

                <?php echo Form::select('curso', $cursos, ['class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('Nome da Turma'); ?>

                <?php echo Form::text('nome', null, ['class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('Data de In&iacute;cio'); ?>

                <?php echo Form::text('data_inicio', null, ['id'=>'data_inicio','class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('Salvar', ['class' => 'btn btn-primary']); ?>

            </div>

        <?php echo Form::close(); ?>

    </div>
    <div class="container">
        <h4>Lista de Turmas</h4>
        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Nome da Turma</th>
                <th>Data de In&iacute;cio</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>

            </tr>
            </thead>
            <tbody>
            <?php foreach($turmas as $turma): ?>
                <tr>
                    <td><?php echo e($turma->tur_nome); ?></td>
                    <td><?php echo e(implode('/', array_reverse(explode('-', $turma->tur_data_inicio)))); ?></td>
                    <td style="text-align: center">
                        <a href="<?php echo e(route('turmas.edit',['id'=>$turma->id])); ?>" class="btn-sm btn-success">Editar</a>

                    </td>
                    <td style="text-align: center">
                        <a href="<?php echo e(route('turmas.destroy',['id'=>$turma->id])); ?>" class="btn-sm btn-danger">Remover</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('#data_inicio').datepicker({
            format:'dd/mm/yyyy',
            language: 'pt-BR',
            autoclose: true,
            todayHighlight: true
        });
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>