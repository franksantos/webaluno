<?php $__env->startSection('content'); ?>
<div class="container">
    <?php foreach($aluno as $chave): ?>
        <h1>Parcelas do aluno: <?php echo e($chave->alu_nome); ?></h1>
        <a href="<?php echo e(url('mensalidade/create')); ?>" class="btn btn-success">Voltar</a>
    <?php endforeach; ?>

    <table class="table table-striped table-bordered table-hover">
        <thead>
        <tr>
            <th>Parcela</th>
            <th>Valor</th>
            <th>Data de Vencimento</th>
            <th>Status</th>
            <th colspan="2" style="text-align: center">A&ccedil;&otilde;es</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($mensalidades as $mensalidade): ?>
            <tr>
                <td><?php echo e($mensalidade->mes_num); ?></td>
                <td><?php echo e($mensalidade->mes_valor); ?></td>
                <td><?php echo e($mensalidade->mes_data_venc); ?></td>
                <td><?php echo e($mensalidade->mes_status); ?></td>
                <td style="text-align: center">
                    <a href="<?php echo e(route('mensalidades.edit',['id'=>$mensalidade->mes_id])); ?>" class="btn-sm btn-success">Editar</a>

                </td>
                <td style="text-align: center">
                    <a href="<?php echo e(route('mensalidades.destroy',['id'=>$mensalidade->mes_id])); ?>" class="btn-sm btn-danger">Remover</a>
                </td>

            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>