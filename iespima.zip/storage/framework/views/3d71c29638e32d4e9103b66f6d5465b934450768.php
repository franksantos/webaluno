<?php $__env->startSection('content'); ?>
    <?php if($sucesso==true): ?>
        <!-- div para exibir uma mensagem de confirmacao se o foi realmente cadastrado com SUCESSO -->
        <!-- Modal Mensagem  -->
        <!-- inicio -->
        <div class="modal fade" id="sucessoAjax" tabindex="-1" role="dialog" aria-     labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">SALVO COM SUCESSO</h4>
                    </div>
                    <div class="modal-body">
                        <p id="retorno">

                        </p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Fechar</button>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
        <!-- FIM Mensagem de SUCESSO-->
    <?php endif; ?>
    <div class="container">
        <div class="box box-header">
            <h3 class="box-title">Cadastro de Aluno</h3>
        </div>

        <?php echo Form::open(array('url' => 'aluno/store')); ?>


        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <?php echo Form::label('Turma'); ?>

                    <?php echo Form::select('turma', $turmas,'', ['class' => 'form-control']); ?>

                    <?php if($errors->has('turma')): ?><p class="alert alert-danger"><?php echo e($errors->first('turma')); ?></p><?php endif; ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <?php echo Form::label('Nome'); ?>

                    <?php echo Form::text('nome', null, ['id'=>'nome','class' => 'form-control']); ?>

                    <?php if($errors->has('nome')): ?><p class="alert alert-danger"><?php echo e($errors->first('nome')); ?></p><?php endif; ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <?php echo Form::label('CPF'); ?>

                    <?php echo Form::text('cpf', null, ['id'=>'cpf','class' => 'form-control']); ?>

                    <?php if($errors->has('cpf')): ?><p class="alert alert-danger"><?php echo e($errors->first('cpf')); ?></p><?php endif; ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <?php echo Form::label('Telefone'); ?>

                    <?php echo Form::text('telefone', null, ['id'=>'telefone','class' => 'form-control']); ?>

                    <?php if($errors->has('telefone')): ?><p class="alert alert-danger"><?php echo e($errors->first('telefone')); ?></p> <?php endif; ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <?php echo Form::submit('Salvar', ['class' => 'btn btn-block btn-primary btn-lg']); ?>

                </div>
            </div>

        </div>

        <?php echo Form::close(); ?>


        <div class="container">
                <h4>Lista de Alunos</h4>
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>Telefone</th>
                        <th colspan="2" style="text-align: center">A&ccedil;&otilde;es</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($alunos as $aluno): ?>
                        <tr>
                            <td><?php echo e($aluno->alu_nome); ?></td>
                            <td><?php echo e($aluno->alu_cpf); ?></td>
                            <td><?php echo e($aluno->alu_tel); ?></td>
                            <td style="text-align: center">
                                <a href="<?php echo e(route('alunos.edit',['id'=>$aluno->id])); ?>" class="btn-sm btn-success">Editar</a>

                            </td>
                            <td style="text-align: center">
                                <a href="<?php echo e(route('alunos.destroy',['id'=>$aluno->id])); ?>" class="btn-sm btn-danger">Remover</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        //m�scara para o cpf
        $('#cpf').inputmask("999.999.999-99", {"placeholder": "___.___.___-__"});
        //m�scara para o telefone
        $('#telefone').inputmask("(99) 99999-9999", {"placeholder": "(__) _____-____"});
    </script>
    <!-- valida��o do cpf do aluno -->
    <script> function TestaCPF(strCPF) {
            var Soma;
            var Resto;
            Soma = 0;
            if (strCPF == "00000000000") return false;
            for (i=1; i<=9; i++) Soma = Soma + parseInt(strCPF.substring(i-1, i)) * (11 - i);
            Resto = (Soma * 10) % 11;
            if ((Resto == 10) || (Resto == 11)) Resto = 0;
            if (Resto != parseInt(strCPF.substring(9, 10)) ) return false;
            Soma = 0;
            for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i-1, i)) * (12 - i);
            Resto = (Soma * 10) % 11;
            if ((Resto == 10) || (Resto == 11)) Resto = 0;
            if (Resto != parseInt(strCPF.substring(10, 11) ) ) return false;
            return true;
        }
        var strCPF = "12345678909";
        //alert(TestaCPF(strCPF));
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>