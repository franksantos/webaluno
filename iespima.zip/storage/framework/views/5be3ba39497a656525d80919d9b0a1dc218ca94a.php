<?php $__env->startSection('content'); ?>

        <!-- inicio contedudo lista de alunos e suas mensalidade -->
<div class="container">
    <div class="box box-header">
        <h3 class="box-title">Confirma&ccedil;&atilde;o de Pagamento</h3>
    </div>
</div>
<?php if($flag['acao'] == 'listar'): ?>
    <div class="container">
        <?php foreach($alunos as $chave): ?>
            <h4>Parcelas do aluno: <span class="label label-success"><?php echo e($chave->alu_nome); ?></span></h4>
        <?php endforeach; ?>
        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Parcela</th>
                <th>Valor</th>
                <th>Data de Vencimento</th>
                <th>Status</th>
                <th style="text-align: center">A&ccedil;&otilde;es</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($mensalidades as $mensalidade): ?>
                <tr>
                    <td><?php echo e($mensalidade->mes_num); ?></td>
                    <td><?php echo e($mensalidade->mes_valor); ?></td>
                    <td><?php echo e($mensalidade->mes_data_venc->format('d/m/Y')); ?></td>
                    <td>
                        <?php if($mensalidade->mes_status == 'Pago'): ?>
                            <p class="text-success"><strong><?php echo $mensalidade->mes_status; ?></strong></p>
                        <?php else: ?>
                            <p class="text-danger"><strong><?php echo $mensalidade->mes_status; ?></strong></p>
                        <?php endif; ?>
                    </td>
                    <td style="text-align: center">
                        <a href="<?php echo e(route('mensalidades.edit',['id'=>$mensalidade->cod])); ?>" class="btn-sm btn-success">Ver Detalhes do Pagto</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    </div>
<?php endif; ?>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>