<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="box box-header">
            <h3 class="box-title">Cadastro de Curso</h3>
        </div>

        <!-- validacao de erros -->
        <?php if($errors->any()): ?>
            <ul class="alert alert-warning">
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>


        <?php echo Form::open(array('url' => 'curso/store')); ?>

        <div class="form-group">
            <?php echo Form::label('Polo'); ?>

            <?php echo Form::select('polo', $todosPolos); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('Nome do Curso'); ?>

            <?php echo Form::text('nome', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('Area do Curso'); ?>

            <?php echo Form::select('area',
                [''=>'Selecione a Area','Ciencias Exatas e da Terra'=>'Ci&ecirc;ncias Exatas e da Terra',
                'Ciencias Humanas'=>'Ci&ecirc;ncias Humanas',
                'Ciencias da Saude'=>'Ci&ecirc;ncias da Saude',
                'Engenharias'=>'Engenharias',
                'Ciencias Biologicas'=>'Ci&ecirc;ncias Biologicas', ''],'', ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::submit('Salvar', ['class' => 'btn btn-primary']); ?>

        </div>

        <?php echo Form::close(); ?>

    </div>
    <div class="container">
        <h4>Lista de Cursos</h4>
        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Cod</th>
                <th>Nome</th>
                <th>Area</th>
                <th colspan="2" style="text-align: center">A&ccedil;&otilde;es</th>


            </tr>
            </thead>
            <tbody>
            <?php foreach($cursos as $curso): ?>
                <tr>
                    <td><?php echo e($curso->id); ?></td>
                    <td><?php echo e($curso->cur_nome); ?></td>
                    <td><?php echo e($curso->cur_area); ?></td>
                    <td style="text-align: center">
                        <a href="<?php echo e(route('cursos.edit',['id'=>$curso->id])); ?>" class="btn-sm btn-success">Editar</a>
                    </td>
                    <td style="text-align: center">
                        <a href="<?php echo e(route('cursos.destroy',['id'=>$curso->id])); ?>" id="btnRemover" class="btn-sm btn-danger">Remover</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>



    <!-- div para exibir uma mensagem de confirmacao se o usuario deseja realmente excluir um curso -->
    <!-- Modal Mensagem  -->
    <!-- inicio -->
    <div class="modal fade" id="sucessoAjax" tabindex="-1" role="dialog" aria-     labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">SALVO COM SUCESSO</h4>
                </div>
                <div class="modal-body">
                    <p id="retorno">

                    </p>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Fechar</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- FIM Mensagem de SUCESSO-->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
       /* $("#btnRemover").click(function(event){
            event.preventDefault();
        });*/
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>