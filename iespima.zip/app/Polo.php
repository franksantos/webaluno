<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Polo extends Model
{
    //
    public $table = "polo";
}
